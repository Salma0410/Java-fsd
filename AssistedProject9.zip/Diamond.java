interface A {

    void display();

}



interface B extends A {

    void show();

}



interface C extends A {

    void print();

}



class D implements B, C {



	public void display() {

      

		System.out.println("Display method in class D");

    }



    

    public void show() {

        

    	System.out.println("Show method in class D");

    }







    public void print() {

        

    	System.out.println("Print method in class D");

    }

}



public class Diamond {

    

	public static void main(String[] args) {

       

		D obj = new D();

        

		obj.display(); 

        obj.show();     

        obj.print();    

    }

}

