public class Main3 {



	public static void main(String[] args) {

		

		       

		        MethodExample.staticMethod();



		       

		        MethodExample instance = new MethodExample();



		        

		        instance.instanceMethod();



		        

		        instance.methodWithParameters(5, 7);



		        

		        instance.methodOverloading();

		        instance.methodOverloading(42);

		        instance.methodOverloading("Hello, Method Overloading!");



		        

		        MethodExample originalObject = new MethodExample();

		        originalObject.overriddenMethod();



		        Subclass subclassObject = new Subclass();

		        subclassObject.overriddenMethod();

		    }

		





	}





